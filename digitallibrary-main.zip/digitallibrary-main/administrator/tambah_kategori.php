<h5>Halaman Tambah Data Kategori</h5>
<a href="?url=data_kategori" class="btn btn-outline-primary">Kembali</a>
<hr>
<form method="post" action="?url=simpan_tambah_kategori">
	<div class="form-group mb-2">
		<label>Nama Kategori</label>
		<input type="text" name="kategori"  class="form-control" required>
	</div>
	<div class="form-group">
		<button type="submit" class="btn btn-outline-success">SIMPAN</button>

		<button type="reset" class="btn btn-outline-warning">KOSONGKAN</button>
	</div>
</form>